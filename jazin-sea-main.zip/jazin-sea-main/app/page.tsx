import Script from "next/script";


const page = () => {


    return  <>
    <Script src="/load.js"/>
    </>
}


export default page;